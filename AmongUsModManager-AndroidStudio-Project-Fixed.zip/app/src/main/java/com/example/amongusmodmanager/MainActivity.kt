package com.example.amongusmodmanager

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.view.Gravity
import android.widget.*
import java.io.File
import java.util.zip.ZipInputStream

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private val folder by lazy { File(filesDir, "mods").apply { mkdirs() } }
    private val pickFile = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        val title = TextView(this).apply {
            text = "Among Us Mod Manager"
            textSize = 24f
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 20)
        }
        status = TextView(this).apply {
            text = "Import and organize your mod files."
            textSize = 14f
            setPadding(0, 0, 0, 16)
        }
        val import = Button(this).apply {
            text = "Import mod file"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "*/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                startActivityForResult(intent, pickFile)
            }
        }
        val refresh = Button(this).apply {
            text = "Refresh files"
            setOnClickListener { refreshList() }
        }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(title)
        root.addView(status)
        root.addView(import)
        root.addView(refresh)
        root.addView(list)
        setContentView(ScrollView(this).apply { addView(root) })
        refreshList()
    }

    @Deprecated("Deprecated in Android API, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickFile && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                val name = queryName(uri).replace(Regex("[^A-Za-z0-9._-]"), "_")
                val destination = uniqueFile(name)
                contentResolver.openInputStream(uri)?.use { input ->
                    destination.outputStream().use { output -> input.copyTo(output) }
                }
                status.text = "Imported: ${destination.name}"
                refreshList()
            } catch (e: Exception) {
                status.text = "Import failed: ${e.message}"
            }
        }
    }

    private fun queryName(uri: Uri): String {
        val cursor = contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            val index = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (it.moveToFirst() && index >= 0) return it.getString(index)
        }
        return "imported_mod_${System.currentTimeMillis()}"
    }

    private fun uniqueFile(name: String): File {
        var target = File(folder, name)
        var n = 1
        while (target.exists()) {
            val dot = name.lastIndexOf('.')
            target = if (dot > 0) File(folder, name.substring(0, dot) + "_$n" + name.substring(dot))
                     else File(folder, "${name}_$n")
            n++
        }
        return target
    }

    private fun refreshList() {
        list.removeAllViews()
        val files = folder.listFiles()?.sortedBy { it.name.lowercase() } ?: emptyList()
        if (files.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "No files imported yet."
                setPadding(0, 20, 0, 20)
            })
            return
        }
        files.forEach { file ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, 14, 0, 14)
            }
            row.addView(TextView(this).apply {
                text = "${file.name}  (${file.length() / 1024} KB)"
                textSize = 16f
            })
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            if (file.extension.equals("zip", true)) {
                actions.addView(Button(this@MainActivity).apply {
                    text = "Extract ZIP"
                    setOnClickListener { extractZip(file) }
                })
            }
            actions.addView(Button(this@MainActivity).apply {
                text = "Delete"
                setOnClickListener {
                    file.delete()
                    status.text = "Deleted ${file.name}"
                    refreshList()
                }
            })
            row.addView(actions)
            list.addView(row)
        }
    }

    private fun extractZip(zipFile: File) {
        try {
            val outputDir = File(folder, zipFile.nameWithoutExtension).apply { mkdirs() }
            ZipInputStream(zipFile.inputStream().buffered()).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    val out = File(outputDir, entry.name).canonicalFile
                    if (out.path != outputDir.canonicalPath &&
                        !out.path.startsWith(outputDir.canonicalPath + File.separator)) {
                        throw SecurityException("Unsafe ZIP entry")
                    }
                    if (entry.isDirectory) out.mkdirs() else {
                        out.parentFile?.mkdirs()
                        out.outputStream().use { zis.copyTo(it) }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
            status.text = "Extracted into ${outputDir.name}"
            refreshList()
        } catch (e: Exception) {
            status.text = "Extraction failed: ${e.message}"
        }
    }
}
