# Among Us Mod Manager

A simple Android file organizer for Among Us mod files.

## Features
- Import files using Android's file picker
- Store imported files privately in the app
- List imported files
- Extract ZIP archives
- Delete imported files

This app does not install mods into Among Us, run PC mods on Android, or download mods.

## Build
Open this folder in Android Studio and build the debug APK, or use a cloud Android Gradle build service.
