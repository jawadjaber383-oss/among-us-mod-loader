package com.example.amongusmodmanager

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.widget.*
import android.view.Gravity
import android.graphics.Typeface
import android.graphics.Color
import android.view.ViewGroup
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipInputStream

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private lateinit var count: TextView
    private val modsDir by lazy { File(filesDir, "mods").apply { mkdirs() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        refreshList()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(248, 247, 255))
        }

        val title = TextView(this).apply {
            text = "Among Us Mod Manager"
            textSize = 25f
            setTextColor(Color.rgb(35, 31, 55))
            typeface = Typeface.DEFAULT_BOLD
        }
        page.addView(title)

        val subtitle = TextView(this).apply {
            text = "Keep your downloaded mods together."
            textSize = 14f
            setTextColor(Color.rgb(105, 100, 125))
            setPadding(0, 6, 0, 20)
        }
        page.addView(subtitle)

        val import = Button(this).apply {
            text = "＋  Import mod file"
            textSize = 16f
            setOnClickListener { chooseFile() }
        }
        page.addView(import, matchWrap())

        count = TextView(this).apply {
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(50, 45, 70))
            setPadding(0, 26, 0, 12)
        }
        page.addView(count)

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(list)

        val note = TextView(this).apply {
            text = "Files stay inside this app. ZIP files can be extracted to view their contents. This app stores mod files; it does not install or run PC mods."
            textSize = 12f
            setTextColor(Color.rgb(115, 110, 130))
            setPadding(0, 24, 0, 0)
        }
        page.addView(note)

        scroll.addView(page)
        setContentView(scroll)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun chooseFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "application/zip", "application/x-zip-compressed",
                "application/vnd.android.package-archive", "application/octet-stream"
            ))
        }
        startActivityForResult(intent, 41)
    }

    @Deprecated("Deprecated in Android API, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 41 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                val name = safeName(queryName(uri) ?: "mod_${System.currentTimeMillis()}")
                val target = uniqueFile(File(modsDir, name))
                contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "Could not open selected file" }.use { src ->
                        FileOutputStream(target).use { dst -> src.copyTo(dst) }
                    }
                }
                Toast.makeText(this, "Imported ${target.name}", Toast.LENGTH_SHORT).show()
                refreshList()
            } catch (e: Exception) {
                Toast.makeText(this, "Import failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun queryName(uri: Uri): String? {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) return c.getString(0) }
        return uri.lastPathSegment
    }

    private fun safeName(raw: String): String =
        raw.substringAfterLast('/').substringAfterLast('\\').replace(Regex("[^A-Za-z0-9._ -]"), "_")
            .take(100).ifBlank { "mod_file" }

    private fun uniqueFile(file: File): File {
        if (!file.exists()) return file
        val base = file.nameWithoutExtension
        val ext = file.extension
        var i = 2
        while (true) {
            val candidate = File(file.parentFile, "$base ($i)" + if (ext.isNotEmpty()) ".$ext" else "")
            if (!candidate.exists()) return candidate
            i++
        }
    }

    private fun refreshList() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val items = modsDir.listFiles()?.sortedBy { it.name.lowercase() } ?: emptyList()
        count.text = "My Mods  •  ${items.size} file(s)"
        if (items.isEmpty()) {
            val empty = TextView(this).apply {
                text = "No mods yet. Tap Import mod file to add one."
                textSize = 14f
                setTextColor(Color.GRAY)
                setPadding(0, 8, 0, 8)
            }
            list.addView(empty)
        }
        items.forEach { file ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(16, 14, 16, 14)
                setBackgroundColor(Color.WHITE)
            }
            val name = TextView(this).apply {
                text = file.name
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.rgb(45, 40, 65))
            }
            card.addView(name)
            val details = TextView(this).apply {
                text = "${if (file.isDirectory) "Folder" else formatSize(file.length())}  •  ${file.extension.uppercase().ifBlank { "FILE" }}"
                textSize = 12f
                setTextColor(Color.GRAY)
                setPadding(0, 4, 0, 8)
            }
            card.addView(details)
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            if (file.isFile && file.extension.equals("zip", true)) {
                val extract = Button(this).apply {
                    text = "Extract ZIP"
                    setOnClickListener { extractZip(file) }
                }
                actions.addView(extract, LinearLayout.LayoutParams(0, -2, 1f))
            }
            val delete = Button(this).apply {
                text = "Delete"
                setOnClickListener {
                    AlertDialogBuilder.confirm(this@MainActivity, "Delete ${file.name}?") {
                        file.deleteRecursively()
                        refreshList()
                    }
                }
            }
            actions.addView(delete, LinearLayout.LayoutParams(0, -2, 1f))
            card.addView(actions)
            val outer = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, 0, 0, 12)
                addView(card, matchWrap())
            }
            list.addView(outer)
        }
    }

    private fun extractZip(zipFile: File) {
        try {
            val outDir = File(modsDir, zipFile.nameWithoutExtension + "_extracted").apply { mkdirs() }
            var extracted = 0
            ZipInputStream(zipFile.inputStream().buffered()).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    val out = File(outDir, entry.name)
                    val rootPath = outDir.canonicalPath + File.separator
                    if (out.canonicalPath != outDir.canonicalPath && !out.canonicalPath.startsWith(rootPath)) {
                        throw SecurityException("ZIP contains an unsafe file path")
                    }
                    if (entry.isDirectory) out.mkdirs() else {
                        out.parentFile?.mkdirs()
                        FileOutputStream(out).use { dst -> zis.copyTo(dst) }
                        extracted++
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
            Toast.makeText(this, "Extracted $extracted file(s)", Toast.LENGTH_LONG).show()
            refreshList()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not extract ZIP: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun formatSize(bytes: Long): String {
        val kb = bytes / 1024.0
        return if (kb < 1024) "%.1f KB".format(kb) else "%.1f MB".format(kb / 1024)
    }
}

private object AlertDialogBuilder {
    fun confirm(activity: Activity, message: String, yes: () -> Unit) {
        android.app.AlertDialog.Builder(activity)
            .setMessage(message)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ -> yes() }
            .show()
    }
}
